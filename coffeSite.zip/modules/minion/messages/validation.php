<?php

return array(
	'minion_option' => ':field is not a valid option for this task!',
);