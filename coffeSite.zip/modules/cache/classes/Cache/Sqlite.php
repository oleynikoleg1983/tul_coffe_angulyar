<?php defined('SYSPATH') or die('No direct script access.');

class Cache_Sqlite extends Kohana_Cache_Sqlite {}