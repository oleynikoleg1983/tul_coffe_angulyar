<?php defined('SYSPATH') OR die('No direct script access.');

return array(
    'Here is the site name' => 'Здесь будет название сайта!',
    'There will be a site title' => 'Здесь будет title сайта',
    'There will footer site'=>'Здесь будет footer сайта',
    'There is active development of a new site based on the framework KOHANA'=>
    'Ведется активная разработка нового сайта на основе фреймворка KOHANA',
    
    'Authorization'=>'Авторизация',
    'Login'=>'Логин',
    'Password'=>'Пароль',
    'Enter'=>'Войти'
);