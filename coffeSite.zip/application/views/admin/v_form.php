<div id="aut_admin">
    <form action="" method="post">
        <table class="login">
            <tr>
                <th colspan="2"><?php echo  __('Authorization'); ?>:</th>
            </tr>
            <tr>
                <td><?php echo  __('Login'); ?>:</td> 
                <td><input type="text" name="login"></td>
            </tr>
            <tr>
                <td><?php echo  __('Password'); ?>:</td>
                <td><input type="password" name="password"></td>
            </tr>
            <th colspan="2"  style="text-align:right"><input name="btnsubmit" id="button_f" type="submit" value="<?php echo  __('Enter'); ?>"></th>
        </table>
    </form>
</div>
<?php  
 //   echo "STARAT";
   
?>

<script>
</script>



 
	
	
 