Languages <a href='/admin/index/index?lang=eng'> (eng) </a>
<a href='/admin/index/index?lang=ru'> (ru) </a>