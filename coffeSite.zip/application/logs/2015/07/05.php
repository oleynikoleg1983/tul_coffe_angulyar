<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-07-05 06:27:48 --- CRITICAL: ErrorException [ 8 ]: Undefined index: name_category ~ APPPATH\views\admin\v_add_data.php [ 16 ] in Z:\home\localhost\kohana\application\views\admin\v_add_data.php:16
2015-07-05 06:27:48 --- DEBUG: #0 Z:\home\localhost\kohana\application\views\admin\v_add_data.php(16): Kohana_Core::error_handler(8, 'Undefined index...', 'Z:\home\localho...', 16, Array)
#1 Z:\home\localhost\kohana\system\classes\Kohana\View.php(62): include('Z:\home\localho...')
#2 Z:\home\localhost\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('Z:\home\localho...', Array)
#3 Z:\home\localhost\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 Z:\home\localhost\kohana\application\views\admin\v_index.php(26): Kohana_View->__toString()
#5 Z:\home\localhost\kohana\system\classes\Kohana\View.php(62): include('Z:\home\localho...')
#6 Z:\home\localhost\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('Z:\home\localho...', Array)
#7 Z:\home\localhost\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 Z:\home\localhost\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#11 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 Z:\home\localhost\kohana\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 Z:\home\localhost\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in Z:\home\localhost\kohana\application\views\admin\v_add_data.php:16
2015-07-05 06:29:28 --- CRITICAL: ErrorException [ 8 ]: Undefined index: level1 ~ APPPATH\views\admin\v_add_data.php [ 16 ] in Z:\home\localhost\kohana\application\views\admin\v_add_data.php:16
2015-07-05 06:29:28 --- DEBUG: #0 Z:\home\localhost\kohana\application\views\admin\v_add_data.php(16): Kohana_Core::error_handler(8, 'Undefined index...', 'Z:\home\localho...', 16, Array)
#1 Z:\home\localhost\kohana\system\classes\Kohana\View.php(62): include('Z:\home\localho...')
#2 Z:\home\localhost\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('Z:\home\localho...', Array)
#3 Z:\home\localhost\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 Z:\home\localhost\kohana\application\views\admin\v_index.php(26): Kohana_View->__toString()
#5 Z:\home\localhost\kohana\system\classes\Kohana\View.php(62): include('Z:\home\localho...')
#6 Z:\home\localhost\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('Z:\home\localho...', Array)
#7 Z:\home\localhost\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 Z:\home\localhost\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#11 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 Z:\home\localhost\kohana\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 Z:\home\localhost\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in Z:\home\localhost\kohana\application\views\admin\v_add_data.php:16
2015-07-05 11:05:57 --- CRITICAL: ErrorException [ 8 ]: Undefined index: level1 ~ APPPATH\views\admin\v_add_data.php [ 17 ] in Z:\home\localhost\kohana\application\views\admin\v_add_data.php:17
2015-07-05 11:05:57 --- DEBUG: #0 Z:\home\localhost\kohana\application\views\admin\v_add_data.php(17): Kohana_Core::error_handler(8, 'Undefined index...', 'Z:\home\localho...', 17, Array)
#1 Z:\home\localhost\kohana\system\classes\Kohana\View.php(62): include('Z:\home\localho...')
#2 Z:\home\localhost\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('Z:\home\localho...', Array)
#3 Z:\home\localhost\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 Z:\home\localhost\kohana\application\views\admin\v_index.php(26): Kohana_View->__toString()
#5 Z:\home\localhost\kohana\system\classes\Kohana\View.php(62): include('Z:\home\localho...')
#6 Z:\home\localhost\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('Z:\home\localho...', Array)
#7 Z:\home\localhost\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 Z:\home\localhost\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#11 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 Z:\home\localhost\kohana\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 Z:\home\localhost\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in Z:\home\localhost\kohana\application\views\admin\v_add_data.php:17
2015-07-05 11:06:45 --- CRITICAL: ErrorException [ 8 ]: Undefined index: level1 ~ APPPATH\views\admin\v_add_data.php [ 17 ] in Z:\home\localhost\kohana\application\views\admin\v_add_data.php:17
2015-07-05 11:06:45 --- DEBUG: #0 Z:\home\localhost\kohana\application\views\admin\v_add_data.php(17): Kohana_Core::error_handler(8, 'Undefined index...', 'Z:\home\localho...', 17, Array)
#1 Z:\home\localhost\kohana\system\classes\Kohana\View.php(62): include('Z:\home\localho...')
#2 Z:\home\localhost\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('Z:\home\localho...', Array)
#3 Z:\home\localhost\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 Z:\home\localhost\kohana\application\views\admin\v_index.php(26): Kohana_View->__toString()
#5 Z:\home\localhost\kohana\system\classes\Kohana\View.php(62): include('Z:\home\localho...')
#6 Z:\home\localhost\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('Z:\home\localho...', Array)
#7 Z:\home\localhost\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 Z:\home\localhost\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#11 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 Z:\home\localhost\kohana\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 Z:\home\localhost\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in Z:\home\localhost\kohana\application\views\admin\v_add_data.php:17
2015-07-05 21:29:52 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: sel1 ~ APPPATH\views\admin\v_add_data.php [ 18 ] in Z:\home\localhost\kohana\application\views\admin\v_add_data.php:18
2015-07-05 21:29:52 --- DEBUG: #0 Z:\home\localhost\kohana\application\views\admin\v_add_data.php(18): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\localho...', 18, Array)
#1 Z:\home\localhost\kohana\system\classes\Kohana\View.php(62): include('Z:\home\localho...')
#2 Z:\home\localhost\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('Z:\home\localho...', Array)
#3 Z:\home\localhost\kohana\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 Z:\home\localhost\kohana\application\views\admin\v_index.php(26): Kohana_View->__toString()
#5 Z:\home\localhost\kohana\system\classes\Kohana\View.php(62): include('Z:\home\localho...')
#6 Z:\home\localhost\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('Z:\home\localho...', Array)
#7 Z:\home\localhost\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 Z:\home\localhost\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#11 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 Z:\home\localhost\kohana\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 Z:\home\localhost\kohana\index.php(118): Kohana_Request->execute()
#14 {main} in Z:\home\localhost\kohana\application\views\admin\v_add_data.php:18
2015-07-05 21:32:02 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected T_CONSTANT_ENCAPSED_STRING ~ APPPATH\views\admin\v_add_data.php [ 19 ] in file:line
2015-07-05 21:32:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-05 22:35:02 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected T_CLASS ~ APPPATH\classes\Controller\admin\getajax.php [ 5 ] in file:line
2015-07-05 22:35:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-05 22:35:17 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected T_CLASS ~ APPPATH\classes\Controller\admin\getajax.php [ 5 ] in file:line
2015-07-05 22:35:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-05 22:35:23 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected T_CLASS ~ APPPATH\classes\Controller\admin\getajax.php [ 5 ] in file:line
2015-07-05 22:35:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-07-05 22:43:23 --- CRITICAL: ErrorException [ 2 ]: Missing argument 1 for Model_Admin_Datacategory::get_category_for_property(), called in Z:\home\localhost\kohana\application\classes\Controller\admin\Index.php on line 42 and defined ~ APPPATH\classes\Model\admin\datacategory.php [ 26 ] in Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php:26
2015-07-05 22:43:23 --- DEBUG: #0 Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php(26): Kohana_Core::error_handler(2, 'Missing argumen...', 'Z:\home\localho...', 26, Array)
#1 Z:\home\localhost\kohana\application\classes\Controller\admin\Index.php(42): Model_Admin_Datacategory->get_category_for_property()
#2 Z:\home\localhost\kohana\system\classes\Kohana\Controller.php(84): Controller_Admin_Index->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#5 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\localhost\kohana\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\localhost\kohana\index.php(118): Kohana_Request->execute()
#8 {main} in Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php:26
2015-07-05 22:46:31 --- CRITICAL: ErrorException [ 2 ]: Missing argument 1 for Model_Admin_Datacategory::get_category_for_property(), called in Z:\home\localhost\kohana\application\classes\Controller\admin\Index.php on line 42 and defined ~ APPPATH\classes\Model\admin\datacategory.php [ 26 ] in Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php:26
2015-07-05 22:46:31 --- DEBUG: #0 Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php(26): Kohana_Core::error_handler(2, 'Missing argumen...', 'Z:\home\localho...', 26, Array)
#1 Z:\home\localhost\kohana\application\classes\Controller\admin\Index.php(42): Model_Admin_Datacategory->get_category_for_property()
#2 Z:\home\localhost\kohana\system\classes\Kohana\Controller.php(84): Controller_Admin_Index->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#5 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\localhost\kohana\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\localhost\kohana\index.php(118): Kohana_Request->execute()
#8 {main} in Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php:26
2015-07-05 22:46:34 --- CRITICAL: ErrorException [ 2 ]: Missing argument 1 for Model_Admin_Datacategory::get_category_for_property(), called in Z:\home\localhost\kohana\application\classes\Controller\admin\Index.php on line 42 and defined ~ APPPATH\classes\Model\admin\datacategory.php [ 26 ] in Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php:26
2015-07-05 22:46:34 --- DEBUG: #0 Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php(26): Kohana_Core::error_handler(2, 'Missing argumen...', 'Z:\home\localho...', 26, Array)
#1 Z:\home\localhost\kohana\application\classes\Controller\admin\Index.php(42): Model_Admin_Datacategory->get_category_for_property()
#2 Z:\home\localhost\kohana\system\classes\Kohana\Controller.php(84): Controller_Admin_Index->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#5 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\localhost\kohana\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\localhost\kohana\index.php(118): Kohana_Request->execute()
#8 {main} in Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php:26
2015-07-05 22:46:44 --- CRITICAL: ErrorException [ 2 ]: Missing argument 1 for Model_Admin_Datacategory::get_category_for_property(), called in Z:\home\localhost\kohana\application\classes\Controller\admin\Index.php on line 42 and defined ~ APPPATH\classes\Model\admin\datacategory.php [ 26 ] in Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php:26
2015-07-05 22:46:44 --- DEBUG: #0 Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php(26): Kohana_Core::error_handler(2, 'Missing argumen...', 'Z:\home\localho...', 26, Array)
#1 Z:\home\localhost\kohana\application\classes\Controller\admin\Index.php(42): Model_Admin_Datacategory->get_category_for_property()
#2 Z:\home\localhost\kohana\system\classes\Kohana\Controller.php(84): Controller_Admin_Index->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#5 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\localhost\kohana\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\localhost\kohana\index.php(118): Kohana_Request->execute()
#8 {main} in Z:\home\localhost\kohana\application\classes\Model\admin\datacategory.php:26
2015-07-05 22:47:23 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: add_data ~ APPPATH\views\admin\v_index.php [ 26 ] in Z:\home\localhost\kohana\application\views\admin\v_index.php:26
2015-07-05 22:47:23 --- DEBUG: #0 Z:\home\localhost\kohana\application\views\admin\v_index.php(26): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\localho...', 26, Array)
#1 Z:\home\localhost\kohana\system\classes\Kohana\View.php(62): include('Z:\home\localho...')
#2 Z:\home\localhost\kohana\system\classes\Kohana\View.php(359): Kohana_View::capture('Z:\home\localho...', Array)
#3 Z:\home\localhost\kohana\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#4 Z:\home\localhost\kohana\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#5 [internal function]: Kohana_Controller->execute()
#6 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Admin_Index))
#7 Z:\home\localhost\kohana\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 Z:\home\localhost\kohana\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 Z:\home\localhost\kohana\index.php(118): Kohana_Request->execute()
#10 {main} in Z:\home\localhost\kohana\application\views\admin\v_index.php:26