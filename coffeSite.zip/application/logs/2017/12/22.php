<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2017-12-22 13:45:35 --- CRITICAL: ErrorException [ 8 ]: Use of undefined constant Route - assumed 'Route' ~ APPPATH\bootstrap.php [ 197 ] in Z:\home\localhost\coffeSite\application\bootstrap.php:197
2017-12-22 13:45:35 --- DEBUG: #0 Z:\home\localhost\coffeSite\application\bootstrap.php(197): Kohana_Core::error_handler(8, 'Use of undefine...', 'Z:\home\localho...', 197, Array)
#1 Z:\home\localhost\coffeSite\index.php(102): require('Z:\home\localho...')
#2 {main} in Z:\home\localhost\coffeSite\application\bootstrap.php:197