<?php defined('SYSPATH') or die('No direct script access.');



class Model_Admin_Datacategory extends Model {
/*
     protected $_tableArticles = '`category_goods`';
     
      public function get_all_category()
      {
       $sql = "SELECT * FROM ". $this->_tableArticles;
       return DB::query(Database::SELECT, $sql)
              ->execute()
              ->as_array();
      }
     
      
       public function set_category($parent_id, $name_category)
       {
        $query = DB::query(Database::INSERT, 'INSERT INTO `category_goods` VALUES (null, :parent_id, :name_category)') 
                 ->bind(':parent_id', $parent_id)    
                 ->bind(':name_category', $name_category);
        $query->execute();
       }
       
        public function get_category_for_property($parent_id)
       {
        $sql = "SELECT * FROM category_goods  WHERE parent_id=".$parent_id;
        return DB::query(Database::SELECT, $sql)
               ->execute()         
               ->as_array();     
        }
 
 */
    
}