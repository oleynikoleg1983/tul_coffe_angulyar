<?php defined('SYSPATH') or die('No direct script access');

return array(
            'title'=>'Here is the site name',
            'header'=>'There will be a site title',
            'footer'=>'There will footer site'
);