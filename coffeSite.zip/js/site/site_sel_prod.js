/*
var product_sell = function (id, sell_product, id_user) {  // sell product //have_us//так зробити всi!!!
    var enebl_quantity = $('#enebl_quantity' + id).val();
    var dataObj = {
        id_sell: id,
        sell_product: sell_product,
        id_user: id_user
    };
    $.ajax({
        type: "POST",
        url: "http://kohana.localhost/site/Getajax",
        dataType: "JSON",
        data: dataObj,
        success: function (json) {
            {   
                $('#enebl_quantity' + id).val(enebl_quantity - sell_product);
                del_this_el(id); 
            }
        }
    });
}//так зробити всi!!!

function clear_inform_pole(quantity) {
    if (quantity) {
        var delElement = $('#empty_product');
        if (delElement) {
            delElement.remove();
        }
    }
    var delElement = $('#quantity_product');
    if (delElement) {
        delElement.remove();
    }
    var delElement = $('#sort_panel');
    if (delElement) {
        delElement.remove();
    }  
}

function drow_empty_product(){//ничего не найдено
    var show_product = $("<div id='empty_product'>По заданным характеристикам товары отсутствуют.</div>");
    var empty = true;
    clear_inform_pole(empty);
    $('#inform_pole').append(show_product);     
}

function drow_quantity_find_product(quantity){//найдено столько то товаров
    var show_product = $("<div id='quantity_product'>Найдено "+quantity +" шт.</div>");
    clear_inform_pole(quantity);
    drwo_sort_product(quantity);
    $('#inform_pole').append(show_product); 
}

function drwo_sort_product(quantity) {
    if (quantity > 0) {
        var array_sort = new Array;
        var array_sort_rus = {};
        array_sort_rus['name'] = 'по названию';
        array_sort_rus['price'] = 'по цене';
        array_sort_rus['quantity'] = 'по количеству';
        array_sort.push('name');
        array_sort.push('price');
        array_sort.push('quantity');
        var select_sort_prod = $("<div id='sort_panel'>cортировка: </div>");
        var selectList = $("<SELECT onchange='sort_product()' id='sel_sort_elem'>");
        select_sort_prod.append(selectList);
        var sel_sort_elem = $('#find_ned_element').data('sort_product');
        for (var i = 0; i < array_sort.length; i++) {
            if (sel_sort_elem == array_sort[i]) {
                var option = $('<option selected value="' + array_sort[i] + '">' + array_sort_rus[array_sort[i]] + '</option>');
                selectList.append(option);
                continue;
            }
            var option = $('<option value="' + array_sort[i] + '">' + array_sort_rus[array_sort[i]] + '</option>');
            selectList.append(option);
        }
        $('#inform_pole').append(select_sort_prod);
    }
}

function ged_product_ajax(page) { //show sected id_type product
    var sel_sort_elem;
    if($('#find_ned_element').data('sort_product')){
        sel_sort_elem = $('#find_ned_element').data('sort_product');// сортировать по названию или цене 
    }
    else{
        sel_sort_elem ='name'; // сортировать по названию или цене   
    }  
    clear_show_product();// очистка екрана от товаров если они уже были выбраны
    var array_id_product = $('#show_product').data('array_id_product');
    var show_elm = 12;
    var type_find="ged_product_ajax"; //тип поиска для пагинацыи
    $('#filter').data('type_find', type_find);
    var dataObj = {
        selected_type: array_id_product, //масив id товаров
        page:page,
        show_elm:show_elm,
        sel_sort_elem:sel_sort_elem
    };
    $.ajax({
        type: "POST",
        url: "http://kohana.localhost/site/Getajax",
        dataType: "JSON",
        data: dataObj,
        success: function (json) {
            {   
                if (json.length > 0)
                {
                    drow_view_product(json); 
                }
                else{
                    drow_empty_product(); 
                }
                show_pagination(show_elm, page, type_find);
            }
        }
    });          
}

function show_pagination(show_elm, page, type_find) {   
    var page_in_display=0;
    var $type_find_func=0;
    var delElement = $('#show_pagination');
    if (delElement)
    {
        $('#show_pagination').remove();
    }
    var show_pagination = "<div id='show_pagination'>  </div>";
    var array_id_product = $('#show_product').data('array_id_product');
    var dataObj = {
        selected_type_pagination: array_id_product //масив id товаров      
    };
    if(type_find=="find_product"){
    var find_name_product = $('#find_name_product').val();
    var find_code_product = $('#find_code_product').val();
    var sel_sort_elem = $('#sel_sort_elem').val();
    var find_first_prise = $('#find_first_prise').val();
    var find_finish_priset = $('#find_finish_priset').val();
    if(!find_first_prise){
        find_first_prise=0;
    }
    console.log("show_pagination find_first_prise = "+ find_first_prise);
    dataObj = {
        find_code_product: find_code_product,
        find_name_product: find_name_product,
        sel_sort_elem:sel_sort_elem,
        find_first_prise:find_first_prise,
        find_finish_priset:find_finish_priset,
        page:null,
        show_elm:null
    };
    }
    $.ajax({
        type: "POST",
        url: "http://kohana.localhost/site/Getajax",
        dataType: "JSON",
        data: dataObj,
        success: function (json) {
            {  
                drow_quantity_find_product(json.length);
                if (json.length > show_elm)
                { 
                    if(page>0)
                    {   
                        if(type_find=="ged_product_ajax"){   
                        $type_find_func= "onclick='ged_product_ajax("+(page-show_elm)+")'";
                        }
                        if(type_find=="find_product"){
                        $type_find_func= "onclick='find_product("+(page-show_elm)+")'";   
                        }
                        var n_page = "<input class='elem_pagination' "+$type_find_func+" type='button' value='<<<'> ";
                        $('#show_pagination').append(n_page);
                    }
                    for (var i = page/show_elm; i < (json.length)/show_elm; i++) {
                        page_in_display++;
                        if(page_in_display>(show_elm-2)){
                            break;
                        }
                        if(type_find=="ged_product_ajax"){   
                        $type_find_func= "onclick='ged_product_ajax("+i*show_elm+")'";
                        }
                        if(type_find=="find_product"){ 
                        $type_find_func= "onclick='find_product("+(i*show_elm)+")'";   
                        }
                        var number_element_show =  i*show_elm+ ' - '+(i+1)*show_elm;
                        var n_page = "<input class='elem_pagination' "+$type_find_func+" type='button' value='"+number_element_show+"'> ";
                        
                        $('#show_pagination').append(n_page);
                    }
                    if((page_in_display>(show_elm-2))){// последння страница 
                        var num = json.length;
                        num = (Math.floor(num/show_elm))*show_elm;
                        if(type_find=="ged_product_ajax"){   
                        $type_find_func= "onclick='ged_product_ajax("+num+")'";
                        }
                        if(type_find=="find_product"){ 
                        $type_find_func= "onclick='find_product("+(num)+")'";   
                        }
                        var n_page = "<input class='elem_pagination' "+$type_find_func+" type='button' value='..."+num+ ' - '+(num+show_elm)+"'> ";                      
                        $('#show_pagination').append(n_page); 
                    }    
                }

            }
        }
    });
    $('#show_product').append(show_pagination);
}

function clear_show_product() {//dell product in display 
    var delElement = $('#show_product');
    if (delElement)
    {
        $("div.v_goods").remove();
        $("div.v_goods_detail").remove();
        $('#show_pagination').remove();
    }
}

function ged_product() {//show select catigories product
    var selected_type = $('#new_select_el').val.selected_type; // выбраный id типа товара
    if(!selected_type){
        selected_type=0;
    }
    var array_id_product = new Array; // масив дерева id товаров
    array_id_product.push(selected_type);
    var dataObj_type = {
        id_product: selected_type
    };
    $.ajax({
        type: "POST",
        url: "http://kohana.localhost/site/Getajax",
        dataType: "JSON",
        data: dataObj_type,
        success: function (json) {
            {
                if (json.length > 0)
                {
                    var i = 0;
                    var j = 0;
                    var k = 0;
                    while (i < json.length) {
                        if (selected_type == json[i]['parent_id'])
                        { 
                            array_id_product.push(json[i]['id']);
                            while (k < array_id_product.length){
                                while (j < json.length) {
                                    if (array_id_product[k] == json[j]['parent_id']) {
                                       array_id_product.push(json[j]['id']);
                                    }
                                    j++;
                                }
                                k++;
                                j = i;
                            }
                        }
                        i++;
                    }
                }
                var page=0;
                $('#show_product').data('array_id_product', array_id_product);
                ged_product_ajax(page);
            }
        }
    });
}

function sort_product(){
    var type_find = $('#filter').data('type_find');
    var sel_sort_elem = $('#sel_sort_elem').val();
    $('#find_ned_element').data('sort_product', sel_sort_elem);
    if(type_find=="find_product"){
          find_product(0); 
    }
    if(type_find=="ged_product_ajax"){
          ged_product_ajax(0); 
    }
}

function find_product(page){//find product (name, code)
    var sel_sort_elem;
    if($('#find_ned_element').data('sort_product')){
        sel_sort_elem = $('#find_ned_element').data('sort_product');// сортировать по названию или цене 
    }
    else{
        sel_sort_elem = $('#sel_sort_elem').val(); // сортировать по названию или цене   
    }  
    var find_name_product = $('#find_name_product').val();
    var find_code_product = $('#find_code_product').val();
    var find_first_prise = $('#find_first_prise').val();
    var find_finish_priset = $('#find_finish_priset').val();
     if(!find_first_prise){
        find_first_prise=0;
    }
    console.log("show_pagination find_first_prise = "+ find_first_prise);
    
    var type_find="find_product";
    $('#filter').data('type_find', type_find);
    var show_elm = 12; // винести в konfig фаил!!
    clear_show_product();
    var dataObj_type = {
        sel_sort_elem: sel_sort_elem,
        find_name_product: find_name_product,
        find_code_product: find_code_product,
        page:page,
        show_elm:show_elm,
        find_first_prise:find_first_prise,
        find_finish_priset:find_finish_priset
    };
    
    $.ajax({
        type: "POST",
        url: "http://kohana.localhost/site/Getajax",
        dataType: "JSON",
        data: dataObj_type,
        success: function (json) {
            if (json.length > 0){
                drow_view_product(json);   
            }
            else{
                drow_empty_product(); 
            }
        show_pagination(show_elm, page, type_find);
        }
    }); 
}

/*
function drow_view_product(json){
    for (var i = 0; i < (json.length); i++)
    {
        var money_group = "грн.";
        var product_code = json[i]['product_code'];
        var name = json[i]['name'];
        var price = json[i]['price'];
        var description = json[i]['description']; // no realizet
        var quantity = json[i]['quantity'];
        var url = json[i]['url'];
        var id = json[i]['id'];
        if (!url)
        {
            url = 's_img/NIAva.gif';
        }

        var input_bay = ""; //проверка на реэстрацыю пользователя
        if ($('#aut_user').val())
        { //доступно поле продать
            input_bay = '<br /><input   class="quantity" style="color:black; background-color:white;" id="quantity' + id + '" type="text" value="1"/>\n\
                            <input  onclick="product_basket(' + id + ')" class="sell_tov" type="button" value="В корзину"/>';
        }
        var show_product = $('<div id="v_' + id + '" class="v_goods"> \n\
                            <input type="hidden" name="name_product" value="' + name + '" id="name_prod' + id + '"/>\n\
                            <input type="hidden" name="price_product" value="' + price + '" id="price_prod' + id + '"/>\n\
                            <img  class="img_v_goods" src=/' + url + '>\n\
                            <b id="name_mes"> ' + name + '</b> <br />\n\
                            <div class="v_img" style="display:none">\n\
                            <hr><b class="product_code">код товара (' + product_code + ')</b> \n\
                            <br /><b>Цена  </b><span class="inp_data_show_prod">' + price + ' ' + money_group + '</span><hr><br />\n\
                            На складе<input disabled class="quantity" type="text" value=' + quantity + ' id="enebl_quantity' + id + '"/>\n\
                            <input  class="v_button" style="font-size:14px; float:clear; width:95%; margin: 2px; 0px; 0px; 2px;" type="button" value="Описание товара"/><hr>\n\
                            ' + input_bay + '</div></div>');
        $('#show_product').append(show_product);
    }
    hover_v_goods();
}
*/
/*
function clear_catigories(selected_type_lev1, id) {
    var i = level_number() - 1;
    for (var i; i > id; --i)
    {
        delElement = $('#cat_' + i)
        delElement.remove();
    }
    $('#name_cat').remove();
    if (selected_type_lev1 != undefined)
    {
        level_number(id);
    }
    else
    {
        level_number(id + 1);
    }

}

var level_number = (function () {
    var num = 0;
    return function (new_num)
    {
        if (new_num)
        {
            return num = new_num;
        }
        return num++;
    }
}());

function sel_catigories(selected_type_lev1) {
    $('#new_select_el').val.selected_type = selected_type_lev1;
    if(selected_type_lev1=='undefined'){
          return;  
    }
    var name_cat = $('#name_cat');
    if (name_cat)
    {
        var id_element = level_number();
        name_cat.attr("onchange", "clear_catigories(sel_catigories(value)," + id_element + ")");
        name_cat.attr("id", 'cat_' + id_element);
    }
    var dataObj = {
        selected: selected_type_lev1
    };
    $.ajax({
        type: "POST",
        url: "http://kohana.localhost/site/Getajax",
        dataType: "JSON",
        data: dataObj,
        success: function (json) {
            {
                if (json.length > 0)
                {
                    var selectList = $('<SELECT  id="name_cat" onchange="sel_catigories(value)"  class="catigories">');
                    $('#new_select_el').append(selectList);
                    var option = $('<option value="undefined">Отобрать</option>');
                    selectList.append(option);
                    for (var i = 0; i < (json.length); i++)
                    {
                        var option = $('<option value=' + json[i]['id'] + '>' + json[i]['name_category'] + '</option>');
                        selectList.append(option);
                    }
                    $('#name_cat').focus();
                }
            }
        }
    });
    ged_product();
}

var clear_mes = function (id, text_in_mes) {
    $("#v_" + id).find('#name_mes').text(text_in_mes);
    $("#v_" + id).find('#name_mes').css("color", "");
    $("#v_" + id).find('#name_mes').css("fontSize", "");
    $("#v_" + id).find('.v_button').css("display", "block");
};

/*
function hover_v_goods(){
    var intervalID;
    $('.v_goods').hover(function () {
        $this = this;
        intervalID = setTimeout(function () {
            $($this).attr("class", "v_goods_detail");
            $($this).css('position', 'relative');
            $($this).css('background', '#B0C4DE');
            $($this).css('zIndex', '2');
            $($this).find('.v_img').css('display', 'block');
            $($this).find('.v_img').css('background', '#B0C4DE');
        }, 300);
    }, function () {
        $($this).attr("class", "v_goods");
        $($this).css('position', 'relative');
        $($this).css('background', '#87CEFA');
        $($this).css('zIndex', '1');
        $($this).find('.v_img').css('display', 'none');
        clearTimeout(intervalID);
    }
    );
}
*/
/*

function product_basket(id) {
    var sell_product = $('#quantity' + id).val();
    var enebl_quantity = $('#enebl_quantity' + id).val();
    var name = $('#name_prod' + id).val();
    var id_user = $('#id_user').val();
    var price_prod = $('#price_prod' + id).val();
    var array_all_product = $('#site_basket').data('data_prod_in_basket');
    
    if (sell_product <= 0)
    {     
        var text_in_mes = $("#v_" + id).find('#name_mes').text();
        if (text_in_mes !=='нельзя меньше нуля')
        {
            $("#v_" + id).find('#name_mes').text('нельзя меньше нуля');
            $("#v_" + id).find('#name_mes').css("color", "#DC143C");
            $("#v_" + id).find('.v_button').css("display", "none");
            $("#v_" + id).find('#name_mes').css("fontSize", "14px");
            $("#v_" + id).mouseout(function () {
             setTimeout('clear_mes("' + id + '", "' + text_in_mes + '")', 2000);
            });
           
            
        }
        return;
    }
    if (!array_all_product) {
        var array_all_product = new Array;
    }
    for (var i = 0; i < array_all_product.length; i++) {
        if (array_all_product[i]['id'] == id)
        {
            sell_product = parseInt(sell_product) + parseInt(array_all_product[i]['sell_product']);
            if ((enebl_quantity - sell_product) < 0)
            {
                var text_in_mes = $("#v_" + id).find('#name_mes').text();
                if (text_in_mes !== 'уже все продано')
                {
                    $("#v_" + id).find('#name_mes').text('уже все продано');
                    $("#v_" + id).find('#name_mes').css("color", "#DC143C");
                    $("#v_" + id).find('.v_button').css("display", "none");
                    $("#v_" + id).find('#name_mes').css("fontSize", "14px");
                    $("#v_" + id).mouseout(function () {
                        setTimeout('clear_mes("' + id + '", "' + text_in_mes + '")', 1000);
                    });
                }
                return;
            }
            array_all_product[i]['sell_product'] = sell_product;
            $('#sell_product' + id).val(sell_product);
            re_sum_sell_product();
            $('#sum_one_sell_product' + id).val(sell_product * array_all_product[i]['price_prod']);
            return;
        }
    }
    
    if ((enebl_quantity - sell_product) < 0)
    {
        var text_in_mes = $("#v_" + id).find('#name_mes').text();
        if (text_in_mes != 'уже все продано')
        {
            $("#v_" + id).find('#name_mes').text('уже все продано');
            $("#v_" + id).find('#name_mes').css("color", "#DC143C");
            $("#v_" + id).find('.v_button').css("display", "none");
            $("#v_" + id).find('#name_mes').css("fontSize", "14px");
            $("#v_" + id).mouseout(function () {
                setTimeout('clear_mes("' + id + '", "' + text_in_mes + '")', 1000);
            });
        }
        return;
    }

    var array_product_basket = {
        name: name,
        id: id,
        sell_product: sell_product,
        price_prod: price_prod,
        id_user: id_user,
        enebl_quantity: enebl_quantity};
    array_all_product.push(array_product_basket);
    $('#site_basket').data('data_prod_in_basket', array_all_product);
    drow_basket();
    re_sum_sell_product();

    $('#site_basket').hover(function () {
        $this = this;
        $($this).css('width', '295');
        $($this).css('zIndex', '3');
        $($this).css('height', '130');
        $($this).css({fontSize: 14 + 'px'});
    }, function () {
        $($this).css('width', '216');
        $($this).css('zIndex', '1');
        $($this).css('height', '100');
        $($this).css({fontSize: 12 + 'px'});
    }
    );
}

function sell_product_basket(){
    var array_all_product = $('#site_basket').data('data_prod_in_basket');
    for (var i = 0; i < array_all_product.length; i++) {
        var id = (array_all_product[i]['id']);
        var sell_product = (array_all_product[i]['sell_product']);
        var id_user = (array_all_product[i]['id_user']);
        product_sell(id, sell_product, id_user);
    }
}

function drow_basket(){
    $('.prod_basket').remove();
    var array_all_product = $('#site_basket').data('data_prod_in_basket');
    var v_product_basket_in = $('<div id="one_el_basket' + id + '"><div class="prod_basket"><table></table></div></div>');
    
    for (var i = 0; i < array_all_product.length; i++) {
    var id =  array_all_product[i]['id'];
    var name = array_all_product[i]['name'];
    var sell_product = array_all_product[i]['sell_product'];
    var price_prod = array_all_product[i]['price_prod'];
    var elem_product_basket_in = $('<tr><td> \n\
                                <input disabled style="width:20px; font-size:12px; color:white;" id="sell_product' + id + '" type="text" value=' + sell_product + '>  \n\
                                шт. "' + name + '" </td><td> <input disabled style="width:30px; font-size:12px; color:white;" id="sum_one_sell_product' + id + '" type="text" value=' + (price_prod * sell_product) + '>грн.\n\
                                 <input style="cursor:pointer; margin: 0px 2px 0px 10px" onclick="del_this_el(' + id + ')" type="button" value="X"/></td></tr>');
    v_product_basket_in.find('table').append(elem_product_basket_in);
    }
    $('#site_basket').append(v_product_basket_in);
}

function del_this_el(id) {
    var y = 0;
    var new_array_all_product = new Array;
    var array_all_product = $('#site_basket').data('data_prod_in_basket');
    for (var i = 0; i < array_all_product.length; i++) {
        if (array_all_product[i]['id'] == id)
        {
            continue;
        }
        new_array_all_product[y++] = array_all_product[i];
    }
    $('#site_basket').data('data_prod_in_basket', new_array_all_product);
    drow_basket();
    re_sum_sell_product();
}

function re_sum_sell_product() {
    var array_all_product = $('#site_basket').data('data_prod_in_basket');
    var sum_price_product = 0;
    for (var i = 0; i < array_all_product.length; i++) {
        sum_price_product += array_all_product[i]['sell_product'] * array_all_product[i]['price_prod'];
    }
    var del_sum_price_product = $('#sum_price_product');
    if (del_sum_price_product)
    {
        $(del_sum_price_product).remove();
    }
    if (sum_price_product > 0) {
        var v_sum_price_product = $('<idv id="sum_price_product"><b>Cума покупки (' + sum_price_product + ') грн.</b>\n\
            <input id="b_sel_product_basket" onclick="sell_product_basket()" type="button" value="продать" /></div>');
        $('#site_basket').append(v_sum_price_product);
       // $('#b_sel_product_basket').focus();
    }
}

function drow_view_product(json){
    for (var i = 0; i < (json.length); i++)
    {
        var money_group = "грн.";
        var product_code = json[i]['product_code'];
        var name = json[i]['name'];
        var price = json[i]['price'];
        var description = json[i]['description']; // no realizet
        var quantity = json[i]['quantity'];
        var url = json[i]['url'];
        var id = json[i]['id'];
        if (!url)
        {
            url = 's_img/NIAva.gif';
        }

        var input_bay = ""; //проверка на реэстрацыю пользователя
        if ($('#aut_user').val())
        { //доступно поле продать
            input_bay = '<br /><input   class="quantity_sel"  id="quantity' + id + '" type="text" value="1"/>\n\
                            <input  onclick="product_basket(' + id + ')" class="sell_tov" type="button" value="В корзину"/>';
        }
        var show_product = $('<div id="v_' + id + '" class="v_goods"> \n\
                            <input type="hidden" name="name_product" value="' + name + '" id="name_prod' + id + '"/>\n\
                            <input type="hidden" name="price_product" value="' + price + '" id="price_prod' + id + '"/>\n\
                            <div class="adv_div_img"><img  class="img_v_goods" src=/' + url + '></div>\n\
                            <div  class="adv_div_inf"><b id="name_mes"> ' + name + '</b><br /> \n\
                            <b class="product_code">(код товара - ' + product_code + ')</b> \n\
                            <br />Цена  <span class="inp_data_show_prod">' + price + ' ' + money_group + '</span><br />\n\
                            На складе <input disabled class="quantity" type="text" value=' + quantity + ' id="enebl_quantity' + id + '"/>\n\
                             '+ input_bay + '</div>\n\
                            <div class="adv_div_description">Описание <hr>'+description+'\n\
                            </div></div>');
        $('#show_product').append(show_product);
    }
   // hover_v_goods();
}
*/

/*
function hover_v_goods(){
    var intervalID;
    $('.v_goods').hover(function () {
        $this = this;
        intervalID = setTimeout(function () {
            $($this).attr("class", "v_goods_detail");
            $($this).css('position', 'relative');
            $($this).css('background', 'white');
            $($this).css('zIndex', '2');
            $($this).find('.v_img').css('display', 'block');
            $($this).find('.v_img').css('background', 'white');
        }, 300);
    }, function () {
        $($this).attr("class", "v_goods");
        $($this).css('position', 'relative');
        $($this).css('background', 'white');
        $($this).css('zIndex', '1');
        $($this).find('.v_img').css('display', 'none');
        clearTimeout(intervalID);
    }
    );
}
*/

var productsSellObj;
//var sellCount = 1;

function get_coffee_menu() {
       userAdmin =  $("#admin").val();
      
       if (userAdmin && userAdmin == 1) {
           getUsers();
       } 
       
       var dataObj = {
            get_coffee_menu: true
        };
    console.log('statrt', dataObj);
    $.ajax({
        type: "POST",
        url: "/site/Getajax",
        dataType: "JSON",
        data: dataObj,
        success: function (json) {
            {
                if (json.length > 0)
                {   productsSellObj = json;
                    
                    if (userAdmin != 1) {
                        addReportButton();
                        
                        for (var i = 0; i < (json.length); i++){
                            var name = json[i]['name'];
                            var description = json[i]['description'];
                            var price = json[i]['price'];// class="adv_div_img"
                            var element = $('<div style="margin:20px" class="col-xs-3 col-sm-3 col-md-3 col-lg-3" >\n\
                                                <button onclick="product_basket(' + json[i]['id']+')" \n\
                                                style="" type="button" class="btn btn-info btn-lg">\n\
                                                <h2 style="width:210px; margin-bottom: 5px;"><span>'+name+ '<span></h2>\n\
                                                <span>'+description+'</span></br>\n\
                                                <span> Цена:'+price+'</span></button>\n\
                                               </div>');
                        $('#menu_place').append(element);
                        }
                    }
                    
                  
                    console.log('json', json);
                  
                }
            }
        }
    });
}


function product_basket(item) {
    var sellProduct = null; 
    var sellCount = 1;
  
      for (var i = 0; i < (productsSellObj.length); i++) {
          if(productsSellObj[i]['id'] == item){
              console.log('productsSellObj', productsSellObj[i]);
              sellProduct = productsSellObj[i];
          }
      }
        
       var element = $('<div class="sell-menu-coffe"><div\n\
                     class="col-xs-10 col-sm-10 col-md-10 col-lg-10" >\n\
                    <h1 class="text-center"><span class="label label-default">'+sellProduct.name+'</span></h1>\n\
                    <button onclick="addCountPr('+sellProduct.price+')" \n\
                    style="" type="button" class="btn btn-success btn-lg sell-coffe-btn-add"><span style="font-size:40px;" ><span style="margin-top: 5px;" class="glyphicon glyphicon-plus"></span></span></button>\n\
                    <input class="sell-count-element btn" style="font-size:46px;" id="sell-count" value=' + sellCount + '></input>\n\
                    <button onclick="sell_product(' + sellProduct.id +')" \n\
                    style="" type="button" class="btn btn-success btn-lg sell-coffe-btn"><span><span  style="font-size: 55px; width:80px" class="glyphicon glyphicon-ok"></span></button>\n\
                    <button  onclick="close_sell_product(' + sellProduct.id +')" \n\
                    style="" type="button" class="btn btn-default btn-lg sell-coffe-btn"><span><span  style=" font-size: 55px; width:80px" class="glyphicon glyphicon-remove"></span></button><hr style="width:0.1px;">\n\
                    <button style="margin-top: -15px;" onclick="minusCountPr('+sellProduct.price+')" type="button"  class="btn btn-danger btn-lg sell-coffe-btn-add">\n\
                    <span style="font-size:40px;" ><span  style="margin-top: 5px;" class="glyphicon glyphicon-minus"></span></span></button>\n\
                   \n\
                    <span class="label label-primary" style="font-size:46px;"><span>Загалом: </span>\n\
                    <span   id="sell-sum-money"></span>\n\
                    <span style="margin-left:10px"> грн.</span></span>\n\</div></div>');
                    
                    $('#menu_place').append(element); 
                    $("#sell-sum-money").text(sellCount*sellProduct.price);
    
}

function addCountPr(price) {
    sellCount = $("#sell-count").val();
    sellCount ++;
    $("#sell-count").val(sellCount);
    $("#sell-sum-money").text(sellCount*price);
    //$("#sell-sum-money").val(sellCount*price);
}

function minusCountPr(price) {
    sellCount = $("#sell-count").val()
     if (sellCount > 1) {
        sellCount --;
    }
    $("#sell-count").val(sellCount);
    $("#sell-sum-money").text(sellCount*price);
    //$("#sell-sum-money").val(sellCount*price);
   
}

function sell_product(data){
    sellCount = $("#sell-count").val();
    
    var userId =  $("#id_user").val(); 
  //  console.log('data', data);
    //console.log('sellCount', sellCount);
    
    var dataObj = {
        sell_product: true,
        product_id:data,
        product_count:sellCount,
        user_id: userId
    };
    
     //console.log('statrt', dataObj);
    $.ajax({
        type: "POST",
        url: "/site/Getajax",
        dataType: "JSON",
        data: dataObj,
        success: function (json) {
            {
               
            }
        }
    });
    //addReportButton();
    //setTimeout('showReportForUser();', 2000)

      
     close_sell_product(null);
}

function close_sell_product(data){
      $(".sell-menu-coffe").remove();
}

function getUsers () {
    
    var dataObj = {
        get_users: true
    };
    
     $.ajax({
        type: "POST",
        url: "/site/Getajax",
        dataType: "JSON",
        data: dataObj,
        success: function (json) {
            {
                if (json.length > 0)
                { 
                  //  console.log('json', json);
                    getReportMenu(json);
                }
            }
        }
    });
}

function getReportMenu(user) {
   
   if (user) {
        var divElement = $('<br><input type="hidden" id="select_user_id"></div><div class="col-xs-3 col-sm-3 col-md-3 col-lg-3"></div>');
        
        var selectList = $('<SELECT  onchange="setUserIdForReport(value)" class="form-control" name="select_user_id" class="">');
     //   divElement.append(selectList);
        
        var option = $('<option value="0">все</option>');
        selectList.append(option);
        for (var i = 0; i < (user.length); i++)
        {
            var option = $('<option value=' + user[i]['id_user'] + '>' + user[i]['user'] + '</option>');
            selectList.append(option);
        }
        
        divElement.append(selectList);
   }
   
                   // $('#name_cat').focus();
                    
    var date = new Date();
    var nowDAte = date.getFullYear()+'-'+(date.getMonth()+1)+'-'+date.getDate();
   
   
    var element = $('<div style="margin:20px" class="col-xs-12 col-sm-12 col-md-12 col-lg-12" >\n\
    <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3" >\n\
    <label>Начало:<input  value="'+nowDAte+'" class="form-control" type="date" id="report_date1" name="date1"></label></div>\n\
    <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3" >\n\
    <label>Конец:<input value="'+nowDAte+'" class="form-control" type="date" id="report_date2" name="date1"></label></div>\n\
    </div>');
    //Имя:<input  class="form-control" type="text" id="report_text" name="date1"></label></div>
    if (divElement) {
          element.append(divElement);
    }
    
    var button_element = $('<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3" ><button onclick="showReport()" \n\
                      style="" type="button" class="btn btn-info">ОТЧЕТ</button></div>');
    
    element.append(button_element);
    
    $('#report_place').append(element);
   
   
  
   
}

function setUserIdForReport(data) {
   // console.log('data', data);
    $("#select_user_id").val(data);
}

function showReport() {
    
    $(".report-inf-class").remove();
    $("#report-inf").remove();
    $("#detail_report_btn").remove();
    var report_date1 = $("#report_date1").val();
    var report_date2 = $("#report_date2").val();
    var select_user_id = $("#select_user_id").val();
    
     var dataObj = {
        report_product: true,
        report_date1:report_date1,
        report_date2:report_date2,
        user_id: select_user_id
    };
    
     //console.log('statrt', dataObj);
    $.ajax({
        type: "POST",
        url: "/site/Getajax",
        dataType: "JSON",
        data: dataObj,
        success: function (json) {
            {
                if (json.length > 0)
                { 
                     var productCount = 0;
                     var userSalary = 0;
                     var moneyOborot = 0;
                      for (var i = 0; i < (json.length); i++)
                    {
                        productCount += parseInt(json[i]['product_count'], 10);
                        userSalary += parseFloat(json[i]['user_salary']);
                        moneyOborot += (parseInt(json[i]['product_count'], 10)) * (parseInt(json[i]['product_price'], 10)); //.product_count
                    }
                    
                    var element = $('<div id="report-inf" style="margin:20px" class="report-inf-class col-xs-12 col-sm-12 col-md-12 col-lg-12" >\n\
                                    <table><tr><td><span class="bg-info"><h3>Продано  товаров:  </h3></span></td><td><h3 style="margin-left: 20px;"><strong>'+productCount+         '</strong></h3></td> </tr>\n\
                                           <tr><td><span class="bg-info"><h3>Процент от продаж: </h3></span></td><td><h3 style="margin-left: 20px;"><strong>'+userSalary.toFixed(2)+'</strong></h3></td></tr>\n\
                                           <tr><td><span class="bg-info"><h3>Сумма     продаж:  </h3></span></td><td><h3 style="margin-left: 20px;"><strong>'+moneyOborot+          '</strong></h3></td></tr>\n\
                                    </table></div>\n\
                                    <div style="margin-left:25px;"><button id="detail_report_btn" \n\
                      style="" type="button" class="btn btn-info">Детальный ОТЧЕТ</button></div>');
                     $('#report_place').append(element);
                     
                     $('#detail_report_btn').bind('click', function(){
                        drowTableReport(json);
                      })
                }
            }
        }
    });
    
}

function drowTableReport(data) {
    
    var products = [];
    for (var i = 0; i < (productsSellObj.length); i++) {
        products[productsSellObj[i]['id']] = productsSellObj[i]['name']
    }
    
    console.log('products', products);
    var tmpReport  = '';
    for (var i = 0; i < (data.length); i++) {
         tmpReport += '<tr><td>Тип:</td><td><strong style="margin:20px">'+products[data[i]['product_id']]+'</strong></td> <td>Время:</td><td><strong style="margin:20px">'+data[i]['sell_date']+'</strong></td><td>Количество:</td><td><strong style="margin:20px">'+data[i]['product_count']+'</strong></td></tr>';
    }
   
   var element = $('<div id="report-inf" style="margin:20px" class="col-xs-12 col-sm-12 col-md-12 col-lg-12" ><table>'+tmpReport+'</table></div>'); 
   $('#report_place').append(element);

}


///===============
function showReportForUser() {
    console.log('---')
    $(".report-inf-class").remove();
    $("#report-inf").remove();
   // $("#detail_report_btn").remove();
    var date = new Date();
    var nowDAte = date.getFullYear()+'-'+(date.getMonth()+1)+'-'+date.getDate();
    
    var report_date1 = nowDAte;
    var report_date2 = nowDAte;
    var select_user_id =  $("#id_user").val(); 
    
     var dataObj = {
        report_product: true,
        report_date1:report_date1,
        report_date2:report_date2,
        user_id: select_user_id
    };
    
     console.log('statrt----', dataObj);
    $.ajax({
        type: "POST",
        url: "/site/Getajax",
        dataType: "JSON",
        data: dataObj,
        success: function (json) {
            {
                if (json.length > 0)
                { 
                     var productCount = 0;
                     var userSalary = 0;
                     var moneyOborot = 0;
                      for (var i = 0; i < (json.length); i++)
                    {
                        productCount += parseInt(json[i]['product_count'], 10);
                        userSalary += parseFloat(json[i]['user_salary']);
                        moneyOborot += (parseInt(json[i]['product_count'], 10)) * (parseInt(json[i]['product_price'], 10)); //.product_count
                    }
                    
                    var element = $('<div id="report-inf" class="report-inf-class-user" ><div class="label label-warning">\n\
                                    <span class="">Продано  товаров:</span><strong>'+productCount+         '</strong>\n\
                                    <span class="">Процент от продаж:</span><strong>'+userSalary.toFixed(2)+'</strong>\n\
                                    <span class="">Сумма     продаж: </span><strong>'+moneyOborot+          '</strong>\n\
                                  </div></div></div>');
                     $('#report_place').append(element);
                     
                     
                }
            }
        }
    });
    
}


function addReportButton() {
    //console.log('add-----1');
    
    var element = $('<span>\n\
                    <button id="user_detail_report_btn" \n\
                    style="" type="button" class="btn btn-success">ОТЧЕТ</button></span>');
                    $('.autoriset_in_mag').append(element);
    
    $('#user_detail_report_btn').bind('click', function(){
            setTimeout('showReportForUser();', 2000)
            setTimeout('dropReportForUser();', 12000)
    }) //http://oleg1983.testv1.testforhost.com	
}

function dropReportForUser() {
    $(".report-inf-class").remove();
    $("#report-inf").remove();
}
    //setTimeout('showReportForUser();', 2000)