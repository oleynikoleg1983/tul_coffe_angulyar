<div style="text-align: center; padding: 20px;"><h1> ABOUT</h1></div>
<?php echo __("There is active development of a new site based on the framework KOHANA");?>
